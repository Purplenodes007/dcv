# LXD Discord VPS Bot

A Discord prefix-command bot that deploys and manages **LXD containers** on multiple Linux nodes over SSH. The SSH connection can use a Pinggy TCP endpoint.

> This creates LXD **containers**, not KVM virtual machines. Containers share the host kernel and are not equivalent to full VPS VMs.

## Commands

- `!create <cpu> <ram_gb> <disk_gb> [os] [node]`
  - Example: `!create 2 4 30 ubuntu24`
  - Pin to a node: `!create 2 4 30 debian12 node2`
  - OS keys: `ubuntu22`, `ubuntu24`, `debian12`, `debian13`
- `!nodes` — show configured nodes and bot-accounted capacity
- `!capacity` — same capacity view
- `!list` — list deployments
- `!info <deployment_id>`
- `!start <deployment_id>`
- `!stop <deployment_id>`
- `!restart <deployment_id>`
- `!delete <deployment_id>`
- `!help`

**Every command is restricted to Discord user IDs listed in `ADMIN_IDS`.** Do not add untrusted people to that list.

## 1. Prepare each LXD node

Run on every node (Ubuntu/Debian host with LXD installed):

```bash
sudo snap install lxd
sudo lxd init
sudo adduser vpsbot
sudo usermod -aG lxd vpsbot
```

Log in again as `vpsbot` and verify:

```bash
lxc info
lxc list
```

The `vpsbot` account must be able to run `lxc` without sudo. Membership in the `lxd` group is highly privileged: it effectively grants control over the host. Use a dedicated trusted account and secure the SSH key.

For Debian 12/13 hosts, install LXD using the supported package method for your distribution, then initialize it. The guest OS images selected by the bot are independent of the host OS.

## 2. Configure SSH keys and Pinggy

Generate a dedicated key on the machine running the bot:

```bash
ssh-keygen -t ed25519 -f ~/.ssh/lxd_node1 -C discord-lxd-bot
```

Install the public key on the node's `vpsbot` account (use your provider's console or an existing secure SSH route):

```bash
mkdir -p ~/.ssh
chmod 700 ~/.ssh
cat >> ~/.ssh/authorized_keys
# paste the contents of lxd_node1.pub, then Ctrl+D
chmod 600 ~/.ssh/authorized_keys
```

On the node, start a Pinggy TCP tunnel forwarding to its SSH daemon. For example:

```bash
ssh -p 443 -R0:127.0.0.1:22 tcp@free.pinggy.io
```

Pinggy prints a TCP host and port. Put that host and port in `nodes.json`. For a persistent production endpoint, use a Pinggy plan/feature that reserves a stable endpoint; free tunnel endpoints can change and free sessions may time out. See Pinggy's current documentation before relying on it.

From the bot machine, verify the endpoint:

```bash
ssh -i ~/.ssh/lxd_node1 -p PINGGY_PORT vpsbot@PINGGY_HOST 'lxc info'
```

Accept and verify the node host key securely before running the bot. The bot uses Paramiko's system `known_hosts` and rejects unknown host keys; it intentionally does not auto-trust first connections.

Repeat for each node. Use a different SSH key per node if possible.

## 3. Install the bot

On a separate Ubuntu/Debian machine or one of your trusted nodes:

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
mkdir -p ~/lxd-discord-vps-bot
cd ~/lxd-discord-vps-bot
```

Extract/copy the project files into this directory, then:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
cp nodes.example.json nodes.json
nano .env
nano nodes.json
chmod 600 .env nodes.json
```

Fill in:
- `DISCORD_TOKEN`: token from Discord Developer Portal
- `ADMIN_IDS`: your numeric Discord user ID(s), comma-separated
- `nodes.json`: one entry per LXD node, Pinggy host/port, SSH username, private key path, and **admin-defined capacity ceilings**.

The capacity values are scheduling ceilings, not live hardware discovery. Set them conservatively below the node's real available resources. The SQLite database tracks allocations created through this bot; deployments created outside the bot are not counted.

## 4. Discord bot setup

In Discord Developer Portal:
1. Create an application and add a Bot.
2. Copy the bot token into `.env` (never share it).
3. Under Bot > Privileged Gateway Intents, enable **Message Content Intent**.
4. Invite the bot to your server with View Channels, Send Messages, Embed Links, and Read Message History.
5. Copy your Discord user ID with Developer Mode enabled and add it to `ADMIN_IDS`.

Do not grant Administrator permission unless you have a separate reason to do so.

## 5. Start it

```bash
source .venv/bin/activate
python bot.py
```

Test `!nodes`, then try a small test deployment such as:

```text
!create 1 1 5 ubuntu24 node1
```

## 6. Run persistently with systemd (optional)

Create `/etc/systemd/system/lxd-discord-bot.service` (replace paths/user):

```ini
[Unit]
Description=LXD Discord VPS Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=BOT_LINUX_USER
WorkingDirectory=/home/BOT_LINUX_USER/lxd-discord-vps-bot
EnvironmentFile=/home/BOT_LINUX_USER/lxd-discord-vps-bot/.env
ExecStart=/home/BOT_LINUX_USER/lxd-discord-vps-bot/.venv/bin/python /home/BOT_LINUX_USER/lxd-discord-vps-bot/bot.py
Restart=always
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now lxd-discord-bot
sudo journalctl -u lxd-discord-bot -f
```

## Important limitations and production notes

- **Pinggy here is for bot-to-node SSH control.** It does not automatically give each deployed container a public SSH address. The bot currently creates/starts containers and reports the deployment ID/name; container login, public IP/port forwarding, firewall policy, and per-container access need a separate network design. Do not assume a node's Pinggy SSH port can be reused for all guest containers.
- LXD bridge networking, host firewall, and routing vary by node. If guests need public SSH, configure a deliberate per-container proxy/port allocation or a separate tunnel per guest, then add credentials and access delivery only after testing.
- LXD group membership is effectively host-root access. The bot's SSH key is powerful; protect the bot host, `.env`, `nodes.json`, private keys, and database.
- Use SSH host-key verification. Add each node's host key to the bot user's `~/.ssh/known_hosts` after verifying its fingerprint through a trusted channel.
- The bot's resource scheduler accounts for deployments created through its own SQLite database only. Do not run multiple bot copies against separate databases. Back up `deployments.db`.
- Deleting a deployment is destructive and permanent. Only configured admins can run it.
- This starter does not configure firewall rules, billing, backups, quotas against out-of-band containers, or tenant isolation. Review and harden before offering it to other users.
