import os
import re
import json
import shlex
import sqlite3
import secrets
import string
import asyncio
import logging
from pathlib import Path
from datetime import datetime, timezone

import discord
from discord.ext import commands
import paramiko
from dotenv import load_dotenv

load_dotenv()
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("lxd-vps-bot")

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
PREFIX = os.getenv("COMMAND_PREFIX", "!")
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}
DB_PATH = os.getenv("DATABASE_PATH", "deployments.db")
NODES_FILE = os.getenv("NODES_FILE", "nodes.json")
SSH_TIMEOUT = int(os.getenv("SSH_TIMEOUT", "25"))
MAX_NAME_LEN = 40

IMAGES = {
    "ubuntu22": ("ubuntu:22.04", "Ubuntu 22.04"),
    "ubuntu24": ("ubuntu:24.04", "Ubuntu 24.04"),
    "debian12": ("images:debian/12", "Debian 12"),
    "debian13": ("images:debian/13", "Debian 13"),
}

if not TOKEN:
    raise SystemExit("DISCORD_TOKEN is missing. Copy .env.example to .env and fill it.")
if not ADMIN_IDS:
    raise SystemExit("ADMIN_IDS is empty. Add at least one trusted Discord user ID to .env.")

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS deployments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            instance_name TEXT NOT NULL UNIQUE,
            node_id TEXT NOT NULL,
            owner_id INTEGER NOT NULL,
            cpu INTEGER NOT NULL,
            ram_gb INTEGER NOT NULL,
            disk_gb INTEGER NOT NULL,
            os_key TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'created',
            created_at TEXT NOT NULL
        )
        """)


def load_nodes():
    path = Path(NODES_FILE)
    if not path.exists():
        raise RuntimeError(f"{NODES_FILE} not found. Create it from nodes.example.json.")
    data = json.loads(path.read_text())
    nodes = data.get("nodes", [])
    if not nodes:
        raise RuntimeError("No nodes configured in nodes.json.")
    ids = [n.get("id") for n in nodes]
    if len(ids) != len(set(ids)):
        raise RuntimeError("Node IDs in nodes.json must be unique.")
    return nodes


def is_admin(ctx):
    return ctx.author.id in ADMIN_IDS


def admin_only():
    async def predicate(ctx):
        if not is_admin(ctx):
            raise commands.CheckFailure("Only configured bot admins can use this command.")
        return True
    return commands.check(predicate)


def ssh_run(node, command, timeout=SSH_TIMEOUT):
    """Run a safely quoted command on a node through its Pinggy TCP SSH endpoint."""
    ssh = paramiko.SSHClient()
    ssh.load_system_host_keys()
    # First connection prompts cannot be handled by a bot; pin host keys in known_hosts.
    ssh.set_missing_host_key_policy(paramiko.RejectPolicy())
    key_path = os.path.expanduser(node["private_key"])
    pkey = None
    last_error = None
    for key_cls in (paramiko.Ed25519Key, paramiko.RSAKey, paramiko.ECDSAKey):
        try:
            pkey = key_cls.from_private_key_file(key_path)
            break
        except Exception as exc:
            last_error = exc
    if pkey is None:
        raise RuntimeError(f"Could not load SSH private key {key_path}: {last_error}")
    ssh.connect(
        hostname=node["host"],
        port=int(node["port"]),
        username=node["username"],
        pkey=pkey,
        timeout=timeout,
        banner_timeout=timeout,
        auth_timeout=timeout,
        look_for_keys=False,
        allow_agent=False,
    )
    try:
        stdin, stdout, stderr = ssh.exec_command(command, timeout=timeout * 4)
        out = stdout.read().decode(errors="replace")
        err = stderr.read().decode(errors="replace")
        code = stdout.channel.recv_exit_status()
        if code != 0:
            raise RuntimeError((err or out or f"Remote command failed ({code})")[-1800:])
        return out.strip()
    finally:
        ssh.close()


def q(value):
    return shlex.quote(str(value))


def get_usage(node_id):
    with db() as con:
        row = con.execute("""
            SELECT COALESCE(SUM(cpu),0) cpu,
                   COALESCE(SUM(ram_gb),0) ram,
                   COALESCE(SUM(disk_gb),0) disk
            FROM deployments WHERE node_id=? AND status!='deleted'
        """, (node_id,)).fetchone()
    return int(row["cpu"]), int(row["ram"]), int(row["disk"])


def pick_node(cpu, ram, disk, requested=None):
    nodes = load_nodes()
    candidates = []
    for n in nodes:
        if requested and n["id"].lower() != requested.lower():
            continue
        used_cpu, used_ram, used_disk = get_usage(n["id"])
        caps = n["capacity"]
        if (used_cpu + cpu <= int(caps["cpu"]) and
            used_ram + ram <= int(caps["ram_gb"]) and
            used_disk + disk <= int(caps["disk_gb"])):
            candidates.append((used_ram / max(1, int(caps["ram_gb"])), n))
    if not candidates:
        raise RuntimeError("No configured node has enough unallocated capacity for this request.")
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def make_instance_name(owner_id):
    stamp = datetime.now(timezone.utc).strftime("%y%m%d%H%M%S")
    suffix = "".join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(4))
    return f"vps-{owner_id}-{stamp}-{suffix}"[:MAX_NAME_LEN]


def create_instance(node, name, image, cpu, ram, disk):
    # Root disk size is a LXD root-device override; memory and CPU are instance limits.
    cmd = (
        "lxc launch {image} {name} "
        "-c limits.cpu={cpu} "
        "-c limits.memory={ram}GiB "
        "-d root,size={disk}GiB"
    ).format(
        image=q(image), name=q(name), cpu=int(cpu), ram=int(ram), disk=int(disk)
    )
    return ssh_run(node, cmd, timeout=max(SSH_TIMEOUT, 40))


def lxc_action(node, action, name):
    allowed = {"start", "stop", "restart", "delete", "info"}
    if action not in allowed:
        raise ValueError("Unsupported action.")
    if action == "delete":
        cmd = f"lxc delete {q(name)} --force"
    elif action == "info":
        cmd = f"lxc info {q(name)}"
    else:
        cmd = f"lxc {action} {q(name)}"
    return ssh_run(node, cmd)


def get_deployment(deployment_id):
    with db() as con:
        return con.execute(
            "SELECT * FROM deployments WHERE id=?", (deployment_id,)
        ).fetchone()


def node_by_id(node_id):
    for n in load_nodes():
        if n["id"] == node_id:
            return n
    raise RuntimeError(f"Node '{node_id}' is no longer configured.")


@bot.event
async def on_ready():
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)
    log.info("Configured admin IDs: %s", sorted(ADMIN_IDS))


@bot.command(name="help")
async def help_command(ctx):
    embed = discord.Embed(
        title="LXD VPS Bot",
        description="Direct LXD container deployment over SSH/Pinggy. Admin-only commands.",
        color=discord.Color.blurple(),
    )
    embed.add_field(name="Deploy", value="`!create <cpu> <ram_gb> <disk_gb> [os] [node]`\nExample: `!create 2 4 30 ubuntu24`", inline=False)
    embed.add_field(name="OS keys", value="`ubuntu22`, `ubuntu24`, `debian12`, `debian13`", inline=False)
    embed.add_field(name="Manage", value="`!nodes` · `!list` · `!info <id>` · `!start <id>` · `!stop <id>` · `!restart <id>` · `!delete <id>`", inline=False)
    embed.add_field(name="Admin", value="`!capacity` · `!help`", inline=False)
    embed.set_footer(text="Access is restricted to ADMIN_IDS in .env.")
    await ctx.reply(embed=embed, mention_author=False)


@bot.command(name="create")
@admin_only()
async def create_cmd(ctx, cpu: int, ram_gb: int, disk_gb: int, os_key: str = "ubuntu24", node_id: str = None):
    if cpu < 1 or ram_gb < 1 or disk_gb < 5:
        return await ctx.reply("Minimums: CPU 1, RAM 1 GB, disk 5 GB.")
    if cpu > 64 or ram_gb > 512 or disk_gb > 2048:
        return await ctx.reply("Request exceeds the bot's safety ceiling (64 CPU, 512 GB RAM, 2048 GB disk).")
    os_key = os_key.lower()
    if os_key not in IMAGES:
        return await ctx.reply("Unknown OS. Choose: " + ", ".join(IMAGES))
    try:
        node = pick_node(cpu, ram_gb, disk_gb, node_id)
    except Exception as exc:
        return await ctx.reply(f"Cannot allocate: `{exc}`")
    image, os_label = IMAGES[os_key]
    name = make_instance_name(ctx.author.id)
    status = await ctx.reply(
        f"⏳ Deploying `{name}` on **{node['id']}** · {cpu} CPU · {ram_gb} GB RAM · {disk_gb} GB disk · {os_label}..."
    )
    try:
        await asyncio.to_thread(create_instance, node, name, image, cpu, ram_gb, disk_gb)
        with db() as con:
            cur = con.execute("""
                INSERT INTO deployments
                (instance_name,node_id,owner_id,cpu,ram_gb,disk_gb,os_key,status,created_at)
                VALUES (?,?,?,?,?,?,?,?,?)
            """, (name, node["id"], ctx.author.id, cpu, ram_gb, disk_gb, os_key,
                  "running", datetime.now(timezone.utc).isoformat()))
            deploy_id = cur.lastrowid
        embed = discord.Embed(title="VPS deployed", color=discord.Color.green())
        embed.add_field(name="Deployment ID", value=str(deploy_id), inline=True)
        embed.add_field(name="Instance", value=f"`{name}`", inline=True)
        embed.add_field(name="Node", value=f"`{node['id']}`", inline=True)
        embed.add_field(name="Resources", value=f"{cpu} CPU · {ram_gb} GB RAM · {disk_gb} GB disk", inline=False)
        embed.add_field(name="OS", value=os_label, inline=True)
        embed.add_field(name="Access", value="Container created and started. Use the node's LXD console/exec or configure a public SSH/network path separately.", inline=False)
        await status.edit(content=None, embed=embed)
    except Exception as exc:
        log.exception("Deployment failed")
        await status.edit(content=f"❌ Deployment failed on `{node['id']}`: `{str(exc)[:1200]}`")


@bot.command(name="nodes")
@admin_only()
async def nodes_cmd(ctx):
    nodes = load_nodes()
    embed = discord.Embed(title="Configured LXD nodes", color=discord.Color.blurple())
    for n in nodes:
        used = get_usage(n["id"])
        cap = n["capacity"]
        embed.add_field(
            name=n["id"],
            value=f"SSH: `{n['host']}:{n['port']}`\nAllocated: CPU {used[0]}/{cap['cpu']} · RAM {used[1]}/{cap['ram_gb']} GB · Disk {used[2]}/{cap['disk_gb']} GB",
            inline=False,
        )
    await ctx.reply(embed=embed, mention_author=False)


@bot.command(name="capacity")
@admin_only()
async def capacity_cmd(ctx):
    await nodes_cmd(ctx)


@bot.command(name="list")
@admin_only()
async def list_cmd(ctx):
    with db() as con:
        rows = con.execute("SELECT * FROM deployments WHERE status!='deleted' ORDER BY id DESC LIMIT 25").fetchall()
    if not rows:
        return await ctx.reply("No deployments found.")
    lines = [
        f"`{r['id']}` · `{r['instance_name']}` · node `{r['node_id']}` · owner <@{r['owner_id']}> · {r['status']}"
        for r in rows
    ]
    await ctx.reply("\n".join(lines), mention_author=False)


async def run_deployment_action(ctx, deployment_id, action):
    row = get_deployment(deployment_id)
    if not row or row["status"] == "deleted":
        return await ctx.reply("Deployment ID not found.")
    node = node_by_id(row["node_id"])
    msg = await ctx.reply(f"⏳ {action.title()}ing `{row['instance_name']}`...")
    try:
        output = await asyncio.to_thread(lxc_action, node, action, row["instance_name"])
        if action == "delete":
            with db() as con:
                con.execute("UPDATE deployments SET status='deleted' WHERE id=?", (deployment_id,))
        elif action in ("start", "restart"):
            with db() as con:
                con.execute("UPDATE deployments SET status='running' WHERE id=?", (deployment_id,))
        elif action == "stop":
            with db() as con:
                con.execute("UPDATE deployments SET status='stopped' WHERE id=?", (deployment_id,))
        await msg.edit(content=f"✅ `{row['instance_name']}`: {action} completed.")
    except Exception as exc:
        await msg.edit(content=f"❌ {action.title()} failed: `{str(exc)[:1000]}`")


@bot.command(name="start")
@admin_only()
async def start_cmd(ctx, deployment_id: int):
    await run_deployment_action(ctx, deployment_id, "start")


@bot.command(name="stop")
@admin_only()
async def stop_cmd(ctx, deployment_id: int):
    await run_deployment_action(ctx, deployment_id, "stop")


@bot.command(name="restart")
@admin_only()
async def restart_cmd(ctx, deployment_id: int):
    await run_deployment_action(ctx, deployment_id, "restart")


@bot.command(name="delete")
@admin_only()
async def delete_cmd(ctx, deployment_id: int):
    await run_deployment_action(ctx, deployment_id, "delete")


@bot.command(name="info")
@admin_only()
async def info_cmd(ctx, deployment_id: int):
    row = get_deployment(deployment_id)
    if not row or row["status"] == "deleted":
        return await ctx.reply("Deployment ID not found.")
    node = node_by_id(row["node_id"])
    try:
        output = await asyncio.to_thread(lxc_action, node, "info", row["instance_name"])
        await ctx.reply(f"```text\n{output[:1700]}\n```", mention_author=False)
    except Exception as exc:
        await ctx.reply(f"Could not fetch info: `{str(exc)[:1000]}`")


@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        return await ctx.reply("⛔ Only configured bot admins can use this command.")
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.reply("Missing argument. Try `!help`.")
    if isinstance(error, commands.BadArgument):
        return await ctx.reply("Invalid argument. Try `!help`.")
    log.error("Command error: %r", error)
    await ctx.reply(f"Command error: `{str(error)[:800]}`")


if __name__ == "__main__":
    init_db()
    bot.run(TOKEN)
